import { Component } from '@angular/core';

@Component({
  selector: 'app-create-character',
  imports: [],
  standalone: true,
  template: `
    <p>
      create-character works!
    </p>
  `,
  styles: ``
})
export class CreateCharacterComponent {

}
