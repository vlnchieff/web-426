import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Character {
  name: string;
  gender: 'Male' | 'Female' | 'Other';
  class: 'Warrior' | 'Mage' | 'Rogue';
  faction: string;
  startingLocation: string;
  funFact: string;
}

@Component({
  selector: 'app-players',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent {
  characters: Character[] = [
    {
      name: 'Thorn',
      gender: 'Male',
      class: 'Warrior',
      faction: 'The Iron Brotherhood',
      startingLocation: 'Ironhold',
      funFact: 'Thorn once single-handedly defeated a dragon.'
    },
    {
      name: 'Lyra',
      gender: 'Female',
      class: 'Mage',
      faction: 'The Arcane Circle',
      startingLocation: 'Mystvale',
      funFact: 'Lyra can speak to spirits through enchanted mirrors.'
    },
    {
      name: 'Shade',
      gender: 'Other',
      class: 'Rogue',
      faction: 'The Silent Blades',
      startingLocation: 'Shadowreach',
      funFact: 'Shade has never been seen entering or leaving a room.'
    },
    {
      name: 'Bran',
      gender: 'Male',
      class: 'Warrior',
      faction: 'The Iron Brotherhood',
      startingLocation: 'Ironhold',
      funFact: 'Bran once arm-wrestled a troll and won.'
    },
    {
      name: 'Eira',
      gender: 'Female',
      class: 'Mage',
      faction: 'The Arcane Circle',
      startingLocation: 'Mystvale',
      funFact: 'Eira’s spells smell like lavender.'
    },
    {
      name: 'Nyx',
      gender: 'Other',
      class: 'Rogue',
      faction: 'The Silent Blades',
      startingLocation: 'Shadowreach',
      funFact: 'Nyx leaves behind no footprints.'
    },
    {
      name: 'Garrick',
      gender: 'Male',
      class: 'Warrior',
      faction: 'The Iron Brotherhood',
      startingLocation: 'Ironhold',
      funFact: 'Garrick uses a shield made from dragon scales.'
    },
    {
      name: 'Selene',
      gender: 'Female',
      class: 'Mage',
      faction: 'The Arcane Circle',
      startingLocation: 'Mystvale',
      funFact: 'Selene’s staff glows when danger is near.'
    },
    {
      name: 'Vex',
      gender: 'Other',
      class: 'Rogue',
      faction: 'The Silent Blades',
      startingLocation: 'Shadowreach',
      funFact: 'Vex once stole a crown during a royal ceremony.'
    },
    {
      name: 'Kael',
      gender: 'Male',
      class: 'Warrior',
      faction: 'The Iron Brotherhood',
      startingLocation: 'Ironhold',
      funFact: 'Kael trains by wrestling bears.'
    }
  ];
}
