import { Component } from '@angular/core';

@Component({
  selector: 'app-create-guild',
  imports: [],
  standalone: true,
  template: `
    <p>
      create-guild works!
    </p>
  `,
  styles: ``
})
export class CreateGuildComponent {

}
